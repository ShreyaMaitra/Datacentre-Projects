# Lab 2 - Convert WordCount to UrlCount

I have implemented the UrlCount.java using `Regex`. It is basically searching for href patten in the iput file and extracting the url from the same. We have imported `java.util.regex.Pattern` and `java.util.regex.Matcher` in order to achieve the same;

The below code has been implemented.

 Pattern p = Pattern.compile("\\s*(?i)href\\s*=\\s*(\"([^\"]*\")|'[^']*'|([^'\">\\s]+))");
          Matcher m =p.matcher(itr.nextToken().toString());
    while (m.find())       
    {
        //System.out.println("i am in else: "+new Text(m.group(1)));
         context.write(new Text(m.group(1)), one);
    }
       

`Pattern.compile()` compiles the given regular expression into a pattern.
`Matcher` matches the character sequence by interpreting the given pattern.
If it finds the match then `m.find()` returns true else it returns false.
If the match is found then it writes it in the form "/wiki/Cloud_computing" else it doesn't.

Then we executed the same in Google cloud Platform using Data Proc.
Initially we created a cluster with two worker nodes and later edited the number of nodes to four.
Then we imported our files in the envirenment.
After cluster creation we executed make filesystem to create hadoop filesystem.
Then we checked the Hadoop version and update the same in Makefile .
Then we executed `time make run` in order to get the execution time as well. 


Below is the screenshot of the execution time for clusters with two nodes. 

![Screen capture of test output](./2_nodes.PNG)

Below is the screenshot of the execution time for clusters with four nodes. 

![Screen capture of test output](./4_nodes.PNG)

It is seen that the execution time is high when we increased the number of nodes from two to four.

We executed the program by disabling the combiner `job.setCombinerClass(IntSumCombiner.class)`. It was observed that in case of the cluster with four nodes the effect on the execution time was more compared to the one with one node. 

People I worked with : Gaurav Roy

Resources used : https://mkyong.com/regular-expressions/how-to-extract-html-links-with-regular-expression/

